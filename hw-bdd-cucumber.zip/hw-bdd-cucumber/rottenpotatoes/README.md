"canonical" solution to the Rails Intro homework against which to write your scenarios, and the necessary scaffolding for the first couple of scenarios
